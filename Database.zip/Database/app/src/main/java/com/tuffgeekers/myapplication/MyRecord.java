package com.tuffgeekers.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MyRecord extends AppCompatActivity {
Button btn_del;
    TextView tv_name,tv_email,tv_phone,tv_city;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_my_record);
        tv_name=findViewById(R.id.tv_name);
        tv_email=findViewById(R.id.tv_email);
        tv_phone=findViewById(R.id.tv_phone);
        tv_city=findViewById(R.id.tv_city);
        btn_del=findViewById(R.id.btn_del);

        Bundle bundle = getIntent().getExtras();

        //Extract the data…
        String name = bundle.getString("name");
        tv_name.setText(name);

        String email = bundle.getString("email");
        tv_email.setText(email);


        String phone = bundle.getString("phone");
        tv_phone.setText(name);

        String city = bundle.getString("city");
        tv_city.setText(city);

        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserDbHelper  userDbHelper=new UserDbHelper(MyRecord.this);
              //  sqLiteDatabase=userDbHelper.getWritableDatabase();
                userDbHelper.deleteRow(tv_name.getText().toString());
                Toast.makeText(getBaseContext(), "Data deleted", Toast.LENGTH_LONG).show();
                userDbHelper.close();
            }
        });


    }
}