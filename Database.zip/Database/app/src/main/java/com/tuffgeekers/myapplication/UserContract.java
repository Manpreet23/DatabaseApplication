package com.tuffgeekers.myapplication;


public class UserContract {

    public static abstract class NewUserInfo
    {
        public static final String USER_NAME="user_name";

        public static final String USER_EMAIL="user_email";
        public static final String USER_PHONE="user_phone";
        public static final String USER_ADDRESS="user_address";

        public static final String TABLE_NAME="user_info";
    }
}