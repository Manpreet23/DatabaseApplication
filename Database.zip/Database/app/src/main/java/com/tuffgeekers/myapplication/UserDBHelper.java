package com.tuffgeekers.myapplication;

/**
 * Created by hitesh on 2/2/16.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


 class UserDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "USERINFO.DB";
    private static final int DATABASE_VERSION = 5;
    private static final String CREATE_QUERY = "CREATE TABLE " + UserContract.NewUserInfo.TABLE_NAME + "(id INTEGER, " +
            UserContract.NewUserInfo.USER_NAME + " TEXT, "   + UserContract.NewUserInfo.USER_EMAIL + " TEXT ,"+
     UserContract.NewUserInfo.USER_PHONE + " TEXT, "   + UserContract.NewUserInfo.USER_ADDRESS + " TEXT);";

    public UserDbHelper(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.e("DATABASE OPERATION", "Database created / opened.....");

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_QUERY);
        Log.e("DATABASE OPERATION", "Table create..." + CREATE_QUERY);
    }

    public void addinnformation(String name ,String email, String phone,String address,SQLiteDatabase db) {

        ContentValues contentValue = new ContentValues();
        contentValue.put(UserContract.NewUserInfo.USER_NAME, name);

        contentValue.put(UserContract.NewUserInfo.USER_EMAIL, email);
        contentValue.put(UserContract.NewUserInfo.USER_PHONE, phone);
        contentValue.put(UserContract.NewUserInfo.USER_ADDRESS, address);
        db.insert(UserContract.NewUserInfo.TABLE_NAME, null, contentValue);
        Log.e("DATABASE OPERATION", "One row is insert");

    }

    public Cursor getinformation(SQLiteDatabase db) {
        Cursor cursor;
        String[] projections = {UserContract.NewUserInfo.USER_NAME, UserContract.NewUserInfo.USER_EMAIL,UserContract.NewUserInfo.USER_PHONE,UserContract.NewUserInfo.USER_ADDRESS};
        cursor = db.query(UserContract.NewUserInfo.TABLE_NAME, projections, null, null, null, null, null);
        return cursor;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

     public void deleteRow(String value)
     {
         SQLiteDatabase db = this.getWritableDatabase();
         db.execSQL("DELETE FROM " + UserContract.NewUserInfo.TABLE_NAME+ " WHERE "+UserContract.NewUserInfo.USER_NAME+"='"+value+"'");


         db.close();
     }
}