package com.tuffgeekers.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

    private EditText et_name,et_email,et_phone,et_city;
    private Button btn_save, btn_next;
    private SQLiteDatabase db;
    Context context=this;
    private UserDbHelper userDbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeView();
    }

    public void initializeView() {
        et_name = (EditText) findViewById(R.id.et_name);
        et_email = (EditText) findViewById(R.id.et_email);
        et_phone=(EditText)findViewById(R.id.et_phone);
        et_city=(EditText)findViewById(R.id.et_city);
        btn_save=(Button)findViewById(R.id.btn_save);
        btn_next=(Button)findViewById(R.id.btn_next);
        btn_save.setOnClickListener(this);
        btn_next.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.btn_save:
                String name=et_name.getText().toString();
                String email= et_email.getText().toString();
                String phone= et_phone.getText().toString();
                String city= et_city.getText().toString();
               
                userDbHelper=new UserDbHelper(context);
                sqLiteDatabase=userDbHelper.getWritableDatabase();
                userDbHelper.addinnformation(name,email,phone,city,sqLiteDatabase);
                Toast.makeText(getBaseContext(), "Data saved", Toast.LENGTH_LONG).show();
                userDbHelper.close();
                break;
            case R.id.btn_next:
                Intent in=new Intent(MainActivity.this,AllRecord.class);
                startActivity(in);
                break;
        }

    }
}
