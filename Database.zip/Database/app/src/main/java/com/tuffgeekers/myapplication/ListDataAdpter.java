package com.tuffgeekers.myapplication;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListDataAdpter extends ArrayAdapter {
    List list = new ArrayList();

    public ListDataAdpter(Context context, int resource) {
        super(context, resource);
    }

    static class LayoutHandler {
        TextView NAME ,EMAIL,PHONE,ADDRESS;
    }

    public void add(Object object) {
        super.add(object);
        list.add(object);

    }

    public int getCount() {
        return list.size();
    }

    public Object getTtem(int position) {
        return list.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        final LayoutHandler layoutHandler;
        if (row == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(R.layout.details, parent, false);
            layoutHandler = new LayoutHandler();
            layoutHandler.NAME = (TextView) row.findViewById(R.id.et_name_record);

            layoutHandler.EMAIL = (TextView) row.findViewById(R.id.et_email_record);
            layoutHandler.PHONE = (TextView) row.findViewById(R.id.et_phone_record);
            layoutHandler.ADDRESS = (TextView) row.findViewById(R.id.et_address_record);
            row.setTag(layoutHandler);
        } else {
            layoutHandler = (LayoutHandler) row.getTag();
        }
        DataProvider dataProvider = (DataProvider) this.getTtem(position);
        layoutHandler.NAME.setText(dataProvider.getName());

        layoutHandler.EMAIL.setText(dataProvider.getEmail());
        layoutHandler.PHONE.setText(dataProvider.getPhone());
        layoutHandler.ADDRESS.setText(dataProvider.getCity());

        layoutHandler.ADDRESS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                Intent i=new Intent(getContext(),MyRecord.class);
                bundle.putString("name", layoutHandler.NAME.getText()+"");
                bundle.putString("email", layoutHandler.EMAIL.getText()+"");
                bundle.putString("phone", layoutHandler.PHONE.getText()+"");
                bundle.putString("city", layoutHandler.ADDRESS.getText()+"");
                //Add the bundle to the intent
                i.putExtras(bundle);
                getContext().startActivity(i);
            }
        });
        return row;
    }
}