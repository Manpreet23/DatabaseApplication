package com.tuffgeekers.myapplication;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;


public class AllRecord extends Activity{

    ListView listView;
    SQLiteDatabase sqLiteDatabase;
    UserDbHelper userDbHelper;
    Cursor cursor;
    ListDataAdpter listDataAdpter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.record_list);
        listView=(ListView)findViewById(R.id.database_list);
        listDataAdpter=new ListDataAdpter(getApplicationContext(),R.layout.details);
        listView.setAdapter(listDataAdpter);
        userDbHelper=new UserDbHelper(getApplicationContext());
        sqLiteDatabase=userDbHelper.getReadableDatabase();
        cursor=userDbHelper.getinformation(sqLiteDatabase);
        if(cursor.moveToFirst())
        {
            do {
                String name,email,phone,city;
                name= cursor.getString(0);
                email=cursor.getString(1);
                phone=cursor.getString(2);
                city=cursor.getString(3);
                DataProvider dataProvider=new DataProvider(name,email,phone,city);
                listDataAdpter.add(dataProvider);

            }while (cursor.moveToNext());
        }
    }

}
